#!/bin/sh

gedit 0/alpha.water.orig 0/p_rgh 0/U constant/g constant/dynamicMeshDict constant/turbulenceProperties constant/transportProperties system/controlDict system/fvS*  system/setFieldsDict system/decomposeParDict  foam.foam 
