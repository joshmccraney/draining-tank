#!/bin/sh

cp ../geometry/*.stl constant/triSurface
surfaceFeatureExtract
blockMesh
snappyHexMesh -overwrite
