#!/bin/sh

rm -r postProcessing
rm -r processor*
rm 0/alpha.water.gz
setFields
decomposePar
mpirun -np 16 interFoam -parallel
