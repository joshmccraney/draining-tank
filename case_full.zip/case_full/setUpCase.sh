#!/bin/sh

gedit 0/alpha.water.orig 0/p_rgh 0/U constant/g constant/transportProperties system/controlDict system/fvS*  system/setFieldsDict system/decomposeParDict  foam.foam 

# CHANGE /constant/polymesh/boundary patch to symmetryPlane

