#!/bin/sh

rm ./constant/polyMesh/*
ideasUnvToFoam Mesh_full.unv
gunzip ./constant/polyMesh/*.gz
checkMesh
